<?php
$mod_strings['LBL_TARGETLISTS'] = 'Target lists';
