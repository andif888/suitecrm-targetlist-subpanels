<?php
$mod_strings['LBL_TARGETLISTS'] = 'Kontaktlisten';
