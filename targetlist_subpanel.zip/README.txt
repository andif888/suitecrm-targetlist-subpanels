Account Targetlists

 - Adds target list subpanel to accounts

Contact Targetlists

 - Adds target list subpanel to contacts

Lead Targetlists

 - Adds target list subpanel to leads

 https://suitecrm.com/suitecrm/forum/developer-help/11352-how-to-add-a-target-lists-subpanel-to-leads-or-contacts-etc

 https://docs.suitecrm.com/developer/module-installer/
